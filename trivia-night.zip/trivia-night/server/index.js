/**
 * server/index.js
 * TriviaNight — Express + Socket.IO backend
 * Railway-ready: serves built React client, listens on 0.0.0.0
 */

require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const gameRoutes = require('./routes/games');
const questionRoutes = require('./routes/questions');
const playerRoutes = require('./routes/players');
const mediaRoutes = require('./routes/media');
const registerSocketHandlers = require('./sockets');

const app = express();
const server = http.createServer(app);

// On Railway, CLIENT_URL is the same origin (server serves the client)
const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:5173';

const io = new Server(server, {
  cors: { origin: CLIENT_URL, methods: ['GET', 'POST'] },
  pingTimeout: 20000,
  pingInterval: 10000,
  transports: ['websocket', 'polling'],
});

// ---- Middleware ----
app.use(helmet({ contentSecurityPolicy: false })); // CSP off — React needs inline scripts
app.use(cors({ origin: CLIENT_URL }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use('/api/', limiter);
app.use((req, _res, next) => { req.io = io; next(); });

// ---- API Routes ----
app.use('/api/auth', authRoutes);
app.use('/api/games', gameRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/players', playerRoutes);
app.use('/api/media', mediaRoutes);
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', players: io.engine.clientsCount }));

// ---- Serve React build (Railway production) ----
const clientBuild = path.join(__dirname, '../client/dist');
if (fs.existsSync(clientBuild)) {
  app.use(express.static(clientBuild));
  // All non-API routes serve the React app
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api') && !req.path.startsWith('/uploads')) {
      res.sendFile(path.join(clientBuild, 'index.html'));
    }
  });
  console.log('Serving React client from', clientBuild);
}

// ---- Socket handlers ----
registerSocketHandlers(io);

// ---- Start — MUST bind 0.0.0.0 for Railway ----
const PORT = process.env.PORT || 3001;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`TriviaNight running on port ${PORT}`);
});

module.exports = { app, io };
